api_id = 21503264
api_hash = "d27f078c7dd9d21bf9bfc93817318cf3"

admin = [846802033]
bot_username = "layanansimgratis2547bot"
bot_token = "7312750066:AAELOxSpCaZr14JInhA-QUVxAi0RY9p4u_U"
showperpage = 50

url = "https://rekrutm.my.id/h/buat-dan-perpanjang-sim/"